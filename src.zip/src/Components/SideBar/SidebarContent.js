import { GiAutoRepair } from "react-icons/gi";
import { RiTicket2Line } from "react-icons/ri";

import { GiGears } from "react-icons/gi";
import { AiOutlineAudit } from "react-icons/ai";
import { GrVmMaintenance } from "react-icons/gr";
import { MdDashboard , MdTipsAndUpdates , MdEngineering } from "react-icons/md";

export const routes =[
    {
        path:"/",
        name:"Dashboard",
        icon:<MdDashboard size={22}/>
    },
    // {
    //     path:"/pm",
    //     name:"Predictive Maintainence",
    //     icon:<MdTipsAndUpdates size={22}/>
    // },
    // {
    //     path:"/clirt",
    //     name:"Clirt",
    //     icon:<GiAutoRepair size={22}/>
    // },
    {
        path:"/abnormality",
        name:"Abnormality",
        icon:<MdEngineering size={22}/>
    },
    {
        path:"/ticketList",
        name:"TicketList",
        icon:<RiTicket2Line size={22}/>
    },
    {
        path:"/config",
        name:"Configuration",
        icon:<GiGears size={22}/>,
        subNav : [
            {
                path:"/config/audit",
                name:"Audit",
                icon :<AiOutlineAudit size={22} />
            },
            {
                path:"/config/maintainence",
                name:"Maintainence",
                icon :<GrVmMaintenance size={22} />
            },
            
        ],
    },
    
];