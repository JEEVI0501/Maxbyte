import React from 'react'
import {useState} from 'react';
import {Link} from "react-router-dom";
import './Sidebar.css';

const SubMenu = ({ item }) => {
    const [show,setShow] = useState(false);
    const dropDown = () => setShow(!show);

  return (
    
    <Link className="subNav-main" to={item.path} onClick = {item.subNav && dropDown}>
        <div>
            {item.icon}
            <div>{item.name}</div>
        </div>
        <div>{item.subNav}</div>
    </Link>
    
    );
}
export default SubMenu;