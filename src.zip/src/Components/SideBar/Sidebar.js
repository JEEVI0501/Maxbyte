import { motion } from "framer-motion";
import './Sidebar.css';
import {NavLink} from "react-router-dom";

import Logo from "C:/Users/HP/Desktop/maxbytes/src/assets/Logo.jpeg";
import {useState} from 'react';
import { MdMenu } from "react-icons/md";
import {routes} from "./SidebarContent";
import SubMenu from "./SubMenu";

const SubNavigation =(props)=>{
        
    const routes = props.items;
    console.log(routes)
    // return (
    //     <>
        
    //     <ul>
            
    //     {routes.map((routes,index)=>{
            
    //         return (
    //             <NavLink to={routes.path} key={routes.name} className = "sidebar-links">
                    
    //                         {/* <div className = "sideBar.icons">{routes.icon}</div> */}
    //                         <div className = "sideBar.name">{routes.name}</div>
    //             </NavLink>
                
    //         )
    //     }
    //     )}
    //     </ul></>
    //)
    if(!routes) return null;
    return (
    <ul>
      {routes.map((item, index) => {
        return(
             <NavLink to={item.path} key={index} className = "sidebar-links">
                <div className = "sideBar.icons">{item.icon}</div>
                    {
                        <div className = "sideBar.name">{item.name}</div>
                    }
            </NavLink>
        )
      })}
    </ul>
  );
}


const Sidebar = ({children}) => {
  
    const[show,setShow] = useState(false);
    const toggle =() => setShow(!show);

    const[showSubMenu,setShowSubMenu] =useState(false);
    const clicked =() => setShowSubMenu(!showSubMenu);

    

    return (
       // console.log("jjj")
    <div className = "sideBar-main">
        <motion.div animate={{width: show ? "200px" : "60px"}} className = "sideBar-motion" >
        <div className="maxbyte-logo">
            {show && <img alt="logo"
                 src={Logo}
                 width="150"
                  height="40"/>}
        <div className ="sideBar-icons">
            <MdMenu size={25} onClick={toggle} />
        </div></div>
            {routes.map((route,index)=>{
                // <NavLink to={route.path} key={route.name} className = "sidebar-links"  onClick={clicked}>
                  
                //     <div className = "sideBar.icons">{route.icon}</div>
                //     {
                //         show && <div className = "sideBar.name">{route.name}</div>
                     
                //     }
                //     {showSubMenu && <div><SubNavigation items ={route.subNav} /></div>}
                    
                // </NavLink>
                return <SubMenu item ={route} key={index} />
                })}
        </motion.div>
       <main className="sideBar-child">{children}</main>
    </div>
  )
}

export default Sidebar;