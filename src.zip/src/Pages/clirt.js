const clirt = () => {
  return (
    <div>clirt</div>
  )
}

export default clirt