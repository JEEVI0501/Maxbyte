
const config = () => {
  return (
    <div>config</div>
  )
}

export default config;