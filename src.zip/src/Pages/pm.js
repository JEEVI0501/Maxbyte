const pm = () => {
  return (
    <div>Predictive maintainance</div>
  )
}

export default pm