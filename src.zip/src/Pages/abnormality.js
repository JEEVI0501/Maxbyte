import React from 'react'

const abnormality = () => {
  return (
    <div>abnormality</div>
  )
}

export default abnormality
