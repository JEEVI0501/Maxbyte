const dashboard = () => {
  return (
    <div>dashboard</div>
  )
}

export default dashboard