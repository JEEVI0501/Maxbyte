import '../Pages/dashboard.css';

const dashboard = () => {
  return (
    <div className="dashboard-title">dashboard</div>
  )
}

export default dashboard