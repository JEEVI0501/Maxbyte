const ticketList = () => {
  return (
    <div>Ticket List</div>
  )
}

export default ticketList;